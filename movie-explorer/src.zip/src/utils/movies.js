import img1 from '../images/MoviesCard/cards__ID_1.png';
import img2 from '../images/MoviesCard/cards__ID_2.png';
import img3 from '../images/MoviesCard/cards__ID_3.png';
import img4 from '../images/MoviesCard/cards__ID_4.png';
import img5 from '../images/MoviesCard/cards__ID_5.png';
import img6 from '../images/MoviesCard/cards__ID_6.png'

export const movies = [
  { name: '33 слова о дизайне', time: '1ч 42м', img: img1, id: 1 },
  { name: 'Киноальманах "100 лет дизайна"', time: '1ч 42м', img: img2, id: 2 },
  { name: 'В погоне за Бенкси', time: '1ч 42м', img: img3, id: 3 },
  { name: 'Баския, взрыв реальности', time: '1ч 42м', img: img4, id: 4 },
  { name: 'Бег это свобода', time: '1ч 42м', img: img5, id: 5 },
  { name: 'Книготорговцы', time: '1ч 42м', img: img6, id: 6 },
  { name: 'Когла я говорю о Германии ночью', time: '1ч 42м', img: img6, id: 7 },
];